		$(document).ready(function() {
			$("#accordions").accordion(
				{
					collapsible: true
				}
			);
			

		});
